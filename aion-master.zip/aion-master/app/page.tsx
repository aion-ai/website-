import { Button } from "@/components/ui/button"
import { DiagonalPattern } from "@/components/diagonal-pattern"
import { ContactForm } from "@/components/contact-form";
import { Header } from "@/components/header";
import Image from "next/image";
import { FaqSection } from "@/components/faq-section";

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <Header />

      {/* Main Content */}
      <main>
        {/* Hero Section */}
        <section id={'home'} className="container mx-auto max-w-4xl flex min-h-screen flex-col items-center justify-center px-4 mb-16">
          <div className="mt-16 text-center">
            <h1 className="mb-8 text-7xl font-bold">Aion</h1>

            {/* Robot Hand SVG Container */}
            <div className="mb-8 overflow-hidden rounded-2xl h-[50%] bg-gray-100">
              <Image
                src="/handAi.avif"
                alt="AI Robot Hand"
                width={1000}
                height={400}
                className=" bg-cover "
                priority
              />
            </div>

            <h2 className="mb-4 text-2xl font-medium">Vamos abraçar o futuro juntos?</h2>
            <p className="mb-8 text-gray-600">
              Veja como implementar IA e alavancar seu negócio pode ser tão simples como imagina
            </p>
            <Button
              className="rounded-xl bg-black px-16 py-2 text-white hover:bg-gray-900"
            >
              Fale Conosco
            </Button>
          </div>
        </section>

        {/* B2B Services Section */}
        <section id={'business'} className="w-full  bg-gray-50 py-20">
          <div className="container mx-auto max-w-4xl  px-4">
            <div className="mb-16 text-center">
              <h2 className="mb-4 text-3xl font-bold">Conheça nossos serviços B2B</h2>
              <p className="text-gray-600">
                Sua empresa nunca mais será a mesma depois da AION
              </p>
            </div>

            <div className="space-y-20">
              {/* Automações com IA */}
              <div className="grid gap-8 md:grid-cols-2 md:gap-12">
                <div className="mb-8 overflow-hidden rounded-2xl   bg-gray-100">
                  <Image
                    src="/handAi.avif"
                    alt="AI Robot Hand"
                    width={1000}
                    height={400}
                    className=" bg-cover "
                    priority
                  />
                </div>
                <div className="flex flex-col justify-center">
                  <h3 className="mb-4 text-2xl font-bold">Automações com IA</h3>
                  <p className="mb-6 text-gray-600">
                    Implemente uma de nossas automações no seu negócio e comece agora a sentir o que é um negócio do futuro
                  </p>
                  <div>
                    <Button variant="secondary" className="rounded-xl bg-black text-white hover:bg-gray-800">
                      Read More
                    </Button>
                  </div>
                </div>
              </div>
              {/* Teams MAX */}
              <div className="grid gap-8 md:grid-cols-2 md:gap-12 col-start-1">
                <div className="mb-8 overflow-hidden rounded-2xl   bg-gray-100">
                  <Image
                    src="/handAi.avif"
                    alt="AI Robot Hand"
                    width={1000}
                    height={400}
                    className=" bg-cover "
                    priority
                  />
                </div>
                <div className="flex flex-col justify-center md:order-first">
                  <h3 className="mb-4 text-2xl font-bold ">Teams MAX</h3>
                  <p className="mb-6 text-gray-600">
                    Capacite seu time a saber lidar com IA generativa e aumenta muito mais a sua produtividade
                  </p>
                  <div>
                    <Button variant="secondary" className="rounded-xl bg-black text-white hover:bg-gray-800">
                      Saber mais
                    </Button>
                  </div>
                </div>

              </div>

              {/* Business AI */}
              <div className="grid gap-8 md:grid-cols-2 md:gap-12">
                <div className="mb-8 overflow-hidden rounded-2xl   bg-gray-100">
                  <Image
                    src="/handAi.avif"
                    alt="AI Robot Hand"
                    width={1000}
                    height={400}
                    className=" bg-cover "
                    priority
                  />
                </div>

                <div className="flex flex-col justify-center md:order-2">
                  <h3 className="mb-4 text-2xl font-bold">Business AI</h3>
                  <p className="mb-6 text-gray-600">
                    Descubra com apoio dos nossos especialista onde você pode inserir inteligência artificial na sua empresa para melhor performance
                  </p>
                  <div>
                    <Button variant="secondary" className="rounded-xl bg-black text-white hover:bg-gray-800">
                      Saber mais
                    </Button>
                  </div>
                </div>

              </div>



            </div>
          </div>
        </section>

        {/* Small Business Solutions */}
        <section id={'soluctions'} className="w-full py-20">
          <div className="container mx-auto max-w-4xl px-4">
            <div className="mb-16 text-center">
              <h2 className="mb-4 text-3xl font-bold">Soluções para pequenos negócios</h2>
              <p className="text-gray-600">
                Tenha templates prontos para implementar no seu negócio em 24horas
              </p>
            </div>

            <div className="grid gap-8 md:grid-cols-3">
              {/* Site Institucional */}
              <div className=" justify-between overflow-hidden rounded-lg shadow-md">
                <div className="  overflow-hidden    bg-gray-100">
                  <Image
                    src="/handAi.avif"
                    alt="AI Robot Hand"
                    width={1000}
                    height={400}
                    className="h-full w-full "
                    priority
                  />
                </div>
                <div className="p-6">
                  <h3 className="mb-2 text-md font-bold  ">Site Institucional</h3>
                  <p className="mb-6 text-sm text-gray-400">
                    Automatize a criação dos conteúdos do seu site institucional
                  </p>
                  <Button variant="secondary" className="rounded-xl  bg-black text-white hover:bg-gray-800">
                    Read More
                  </Button>
                </div>
              </div>

              {/* Atendimento Humanizado */}
              <div className="overflow-hidden rounded-lg shadow-md">
                <div className="  overflow-hidden    bg-gray-100">
                  <Image
                    src="/handAi.avif"
                    alt="AI Robot Hand"
                    width={1000}
                    height={400}
                    className="h-full w-full "
                    priority
                  />
                </div>
                <div className="p-6">
                  <h3 className="mb-2 text-md font-bold  ">Atendimento Humanizado</h3>
                  <p className="mb-6 text-sm text-gray-400">
                    Atendimento humanizado com IA que direciona seus clientes para sua agenda
                  </p>
                  <Button variant="secondary" className="rounded-xl bg-black text-white hover:bg-gray-800">
                    Read More
                  </Button>
                </div>
              </div>

              {/* Auto Post */}
              <div className="overflow-hidden rounded-lg shadow-md">
                <div className="  overflow-hidden    bg-gray-100">
                  <Image
                    src="/handAi.avif"
                    alt="AI Robot Hand"
                    width={1000}
                    height={400}
                    className="h-full w-full "
                    priority
                  />
                </div>
                <div className="p-6">
                  <h3 className="mb-2 text-md font-bold  ">Auto Post</h3>
                  <p className="mb-6 text-sm text-gray-400">
                    Tenha os roteiros dos seus conteúdos, cria imagens e legendas e efetua postagens
                  </p>
                  <Button variant="secondary" className="rounded-xl bg-black text-white hover:bg-gray-800">
                    Read More
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Courses Section */}
        <section id={'cursos'} className="w-full py-20">
          <div className="container mx-auto max-w-4xl  px-4">
            <div className="mb-16 text-center">
              <p className="mb-4 tracking-[0.2em] text-gray-600">N O S S O S   C U R S O S</p>
              <h2 className="text-3xl font-bold md:text-4xl">
                Conheça nossos curso para você alavancar para você alavancar
              </h2>
            </div>

            <div className="grid gap-8 md:grid-cols-2">
              {/* Copy Paste from Figma */}
              <div className="group overflow-hidden rounded-lg border bg-white p-6">
                <div className="  overflow-hidden rounded-lg  mb-4 bg-gray-100">
                  <Image
                    src="/handAi.avif"
                    alt="AI Robot Hand"
                    width={1000}
                    height={400}
                    className="h-full w-full "
                    priority
                  />
                </div>
                <h3 className="mb-2 text-xl font-bold">Copy Paste from Figma</h3>
                <p className="text-gray-600">
                  Install the Figma plugin and you're ready to convert your designs to a responsive site.
                </p>
              </div>

              {/* Start with Site Templates */}
              <div className="group overflow-hidden rounded-lg border bg-white p-6">
                <div className="  overflow-hidden rounded-lg  mb-4 bg-gray-100">
                  <Image
                    src="/handAi.avif"
                    alt="AI Robot Hand"
                    width={1000}
                    height={400}
                    className="h-full w-full "
                    priority
                  />
                </div>
                <h3 className="mb-2 text-xl font-bold">Start with Site Templates</h3>
                <p className="text-gray-600">
                  Browse dozens of professionally designed templates. Click, duplicate, customize.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Form */}
        <ContactForm />

        {/* Perguntas Frequentes */}
        <FaqSection />

        <section className="w-full  bg-gray-50 py-10">
          <div className="container mx-auto max-w-4xl  px-4">
            <div className="mb-8 text-center">
              <h2 className="mb-4 text-7xl font-bold">AION</h2>
              <p className="text-gray-600 mb-8">
                Let's Embrace de Future
              </p>
              <Button className="rounded-xl bg-black px-16 py-2 text-white hover:bg-gray-900" >
                Fale Conosco
              </Button>
            </div>
          </div>
        </section>

        <footer className="bg-gray-800 text-white py-4">
          <div className="container mx-auto flex items-center justify-between px-4">

            <div className="text-sm">
              © 2025 Sua Empresa. Todos os direitos reservados.
            </div>


            <div className="flex space-x-4">
              <a href="https://facebook.com" target="_blank" className="hover:text-gray-400">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" className="h-6 w-6">
                  <path d="M22.675 0H1.325C.593 0 0 .593 0 1.325v21.351C0 23.407.593 24 1.325 24H12.81v-9.294H9.692v-3.622h3.118V8.413c0-3.1 1.894-4.788 4.658-4.788 1.325 0 2.463.099 2.794.143v3.24l-1.918.001c-1.504 0-1.796.715-1.796 1.763v2.31h3.587l-.467 3.622h-3.12V24h6.116c.73 0 1.325-.593 1.325-1.325V1.325C24 .593 23.407 0 22.675 0z" />
                </svg>
              </a>
              <a href="https://twitter.com" target="_blank" className="hover:text-gray-400">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" className="h-6 w-6">
                  <path d="M24 4.557a9.83 9.83 0 0 1-2.828.775 4.932 4.932 0 0 0 2.165-2.724 9.864 9.864 0 0 1-3.127 1.195 4.918 4.918 0 0 0-8.38 4.482A13.95 13.95 0 0 1 1.671 3.149a4.902 4.902 0 0 0-.665 2.475c0 1.708.869 3.216 2.188 4.099a4.903 4.903 0 0 1-2.228-.616c-.054 2.281 1.581 4.415 3.949 4.89a4.935 4.935 0 0 1-2.224.085 4.92 4.92 0 0 0 4.6 3.419 9.869 9.869 0 0 1-6.102 2.104c-.396 0-.786-.023-1.17-.069a13.945 13.945 0 0 0 7.548 2.212c9.051 0 13.998-7.496 13.998-13.986 0-.21-.005-.423-.014-.634A9.936 9.936 0 0 0 24 4.557z" />
                </svg>
              </a>
              <a href="https://instagram.com" target="_blank" className="hover:text-gray-400">
                <svg xmlns="http://www.w3.org/2000/svg" fill="currentColor" viewBox="0 0 24 24" className="h-6 w-6">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 1.366.062 2.633.34 3.608 1.316.975.975 1.253 2.242 1.316 3.608.058 1.266.07 1.646.07 4.85s-.012 3.584-.07 4.85c-.062 1.366-.34 2.633-1.316 3.608-.975.975-2.242 1.253-3.608 1.316-1.266.058-1.646.07-4.85.07s-3.584-.012-4.85-.07c-1.366-.062-2.633-.34-3.608-1.316-.975-.975-1.253-2.242-1.316-3.608C2.175 15.784 2.163 15.404 2.163 12s.012-3.584.07-4.85c.062-1.366.34-2.633 1.316-3.608C4.524 2.503 5.791 2.225 7.157 2.163 8.423 2.105 8.803 2.163 12 2.163zm0-2.163C8.745 0 8.333.012 7.052.07 5.775.128 4.526.415 3.423 1.518 2.319 2.62 2.033 3.869 1.975 5.146.987 7.148.987 8.334.987 12c0 3.666-.012 4.852.07 6.135.058 1.266.345 2.514 1.448 3.617 1.104 1.103 2.353 1.39 3.62 1.448C8.333 23.988 8.745 24 12 24s3.667-.012 4.948-.07c1.267-.058 2.516-.345 3.62-1.448 1.103-1.103 1.39-2.351 1.448-3.617C23.988 16.852 24 15.666 24 12s-.012-4.852-.07-6.135c-.058-1.267-.345-2.515-1.448-3.617C19.363.345 18.115.058 16.848.07 15.667.012 15.255 0 12 0zm0 5.838a6.162 6.162 0 1 0 0 12.324 6.162 6.162 0 0 0 0-12.324zm0 10.324a4.162 4.162 0 1 1 0-8.324 4.162 4.162 0 0 1 0 8.324zm6.406-11.845a1.44 1.44 0 1 0-.001-2.88 1.44 1.44 0 0 0 0 2.88z" />
                </svg>
              </a>
            </div>
          </div>
        </footer>

      </main>
    </div>
  )
}

