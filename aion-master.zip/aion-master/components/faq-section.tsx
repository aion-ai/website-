import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion"

export function FaqSection() {
  return (
    <section className="w-full py-20">
      <div className="container mx-auto px-4">
        <h2 className="mb-8 text-center text-3xl font-bold">
          Perguntas mais comuns
        </h2>
        <div className="mx-auto max-w-3xl">
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger>What is Framer?</AccordionTrigger>
              <AccordionContent>
                Framer is a web builder for creative pros. Be sure to check out framer.com to learn more.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-2">
              <AccordionTrigger>Is it easy to learn?</AccordionTrigger>
              <AccordionContent>
                Framer is the fastest tool to build sites with, because you can ship your design immediately, instead of having to rebuild your design in code or a second tool.
              </AccordionContent>
            </AccordionItem>
            <AccordionItem value="item-3">
              <AccordionTrigger>Do I need to code?</AccordionTrigger>
              <AccordionContent>
                Framer is an end to end tool that lets everyone design and ship web sites. You don't need a frontend team or web programming course. Just basic canvas skills.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
      </div>
    </section>
  )
}

