"use client"
import React, { useState } from "react";

export const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <header className="fixed top-0 z-50 w-full bg-white border-b-2">
      <div className="container mx-auto max-w-7xl flex h-16 items-center justify-between px-4">
        {/* Logo */}
        <a href="/" className="text-lg font-bold text-gray-800">
          Logo
        </a>

        {/* Button to toggle menu */}
        <button
          className="block md:hidden text-gray-600 focus:outline-none"
          onClick={toggleMenu}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            className="h-6 w-6"
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M4 6h16M4 12h16m-7 6h7"
            />
          </svg>
        </button>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8 text-gray-600">
          <a href="#home" className="text-sm hover:text-gray-900">
            Home
          </a>
          <a href="#business" className="text-sm hover:text-gray-900">
            Para Empresas
          </a>
          <a href="#soluctions" className="text-sm hover:text-gray-900">
            Soluções
          </a>
          <a href="#cursos" className="text-sm hover:text-gray-900">
            Cursos
          </a>
          <a
            href="#contact"
            className="text-sm font-medium hover:text-gray-900"
          >
            Fale com um Especialista
          </a>
        </nav>

        {/* Mobile Dropdown Menu */}
        <div
          className={`${
            isMenuOpen ? "absolute" : "hidden"
          } top-16 left-0 w-full bg-white shadow-md md:hidden`}
        >
          <nav className="flex flex-col items-start p-4 space-y-4 text-gray-600">
            <a href="#home" className="text-sm hover:text-gray-900">
              Home
            </a>
            <a href="#business" className="text-sm hover:text-gray-900">
              Para Empresas
            </a>
            <a href="#soluctions" className="text-sm hover:text-gray-900">
              Soluções
            </a>
            <a href="#cursos" className="text-sm hover:text-gray-900">
              Cursos
            </a>
            <a
              href="#contact"
              className="text-sm font-medium hover:text-gray-900"
            >
              Fale com um Especialista
            </a>
          </nav>
        </div>
      </div>
    </header>
  );
};
