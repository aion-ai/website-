export function DiagonalPattern() {
  return (
    <div className="h-full w-full bg-gray-100">
      <svg width="100%" height="100%" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <pattern id="diagonal-lines" patternUnits="userSpaceOnUse" width="10" height="10" patternTransform="rotate(45)">
            <line x1="0" y1="0" x2="0" y2="10" stroke="#E5E7EB" strokeWidth="8"/>
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#diagonal-lines)"/>
      </svg>
    </div>
  )
}

